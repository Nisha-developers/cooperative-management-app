from django.urls import path, include

urlpatterns = [
   path('users/', include('api.users.urls')),
   path('wallet/', include('api.wallet.urls')),
   path('listings/', include('api.listings.urls')),
   path('loan/', include('api.loan.urls')),
   path('purchase/', include('api.purchase.urls')),
   path('rent/', include('api.rent.urls')),
]